package com.ldstemplevirtualization;


import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class ImageActivity extends AppCompatActivity {

    private ImageView imageView;
    int currentIndex;
    private ArrayList<String> allTempleInfo;
    private TextView textView;

    private static ArrayList<Integer> allImageIds;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        super.setContentView(R.layout.activity_main);


        allTempleInfo = new ArrayList<>();
        readInfoFile();
        //Toast.makeText(this, " allTempleInfo size is " + allTempleInfo.size() , Toast.LENGTH_SHORT).show();


        //currentIndex = 10;

        Intent lastI = getIntent();
        String data = lastI.getStringExtra("eachIndex");
        final String templeUrl = lastI.getStringExtra("templeUrl");

        currentIndex = Integer.parseInt(data);

        //Toast.makeText(this, data + " currentIndex is " + currentIndex , Toast.LENGTH_SHORT).show();

        allImageIds = ImageCache.getAllImageIds();





        LinearLayout.LayoutParams one = new LinearLayout.LayoutParams
                (LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.MATCH_PARENT, 1);





        textView = new TextView(this);
        textView.setText(allTempleInfo.get(currentIndex*3));
        textView.setTextSize(30);
        textView.setGravity(Gravity.CENTER);

        //textView.setLayoutParams(one);


        imageView = new ImageView(this);
        imageView.setImageResource(allImageIds.get(currentIndex));
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        imageView.setLayoutParams(one);



        TextView textView2 = new TextView(this);
        String templeInfoString = "Location: " + allTempleInfo.get(currentIndex*3+1) + "\n " + "Dedicated on: " + allTempleInfo.get(currentIndex*3+2);
        textView2.setText(templeInfoString);
        textView2.setTextSize(15);
        textView2.setGravity(Gravity.CENTER);
        //textView2.setLayoutParams(one);


        Button b = new Button(this);
        b.setText("Click to visit it's Website");
        //b.setLayoutParams(one);
        b.setHeight(100);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getBaseContext(), "Online Access Disabled", Toast.LENGTH_SHORT).show();

                /*
                Intent eachTemplePage= new Intent();
                eachTemplePage.setAction("android.intent.action.VIEW");
                Uri eachTemplePage_url = Uri.parse(templeUrl);
                eachTemplePage.setData(eachTemplePage_url);
                startActivity(eachTemplePage);
                 */

            }
        });





        LinearLayout lnl = new LinearLayout(this);
        lnl.setOrientation(LinearLayout.VERTICAL);

        TextView textViewUseless = new TextView(this);
        textViewUseless.setText(" ");
        textViewUseless.setHeight(100);
        lnl.addView(textViewUseless);

        lnl.addView(textView);

        lnl.addView(imageView);

        TextView textViewUseless2 = new TextView(this);
        textViewUseless2.setText(" ");
        textViewUseless2.setHeight(50);
        lnl.addView(textViewUseless2);

        lnl.addView(textView2);

        lnl.addView(b);

        lnl.setBackgroundColor(Color.parseColor("#66ccff"));


        //((ViewGroup)textView.getParent()).removeView(textView);


        setContentView(lnl);


    }



    public void readInfoFile() {

        try {
            InputStream allTempleInfoFile =  this.getResources().openRawResource(R.raw.temple_info);
            if (allTempleInfoFile != null)
            {
                InputStreamReader ir = new InputStreamReader(allTempleInfoFile);
                BufferedReader br = new BufferedReader(ir);
                String line;
                //read each line
                while (( line = br.readLine()) != null) {
                    allTempleInfo.add(line+"\n");
                }
                allTempleInfoFile.close();
            }
        }
        catch (java.io.FileNotFoundException e)
        {
            Log.d("TestFile", "The File doesn't not exist.");
        }
        catch (IOException e)
        {
            Log.d("TestFile", e.getMessage());
        }

    }

    @Override
    public boolean onTouchEvent(MotionEvent m) {

        if (m.getAction() == MotionEvent.ACTION_DOWN) {
            float downX = m.getX();
            float downY = m.getY();
            //Toast.makeText(this, "touched at " + downX + " " + downY, Toast.LENGTH_SHORT).show();
            this.finish();

        }



        return true;
    }

}
